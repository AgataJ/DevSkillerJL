package com.devskiller.audit.consumer;

import com.devskiller.audit.repository.ProductOrderRepository;
import com.devskiller.audit.service.ProductOrderEventProcessor;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import org.apache.kafka.clients.consumer.ConsumerRecord;

import java.io.IOException;

public class ProductOrderEventReceiver {
    private final ObjectMapper mapper = new ObjectMapper();

    private final ProductOrderRepository productOrderRepository;
    private final ProductOrderEventProcessor processor;

    public ProductOrderEventReceiver(ProductOrderRepository productOrderRepository, ProductOrderEventProcessor processor) {
        this.productOrderRepository = productOrderRepository;
        this.processor = processor;
        mapper.registerModule(new JavaTimeModule());
    }

    public void receive(ConsumerRecord<?, ?> consumerRecord) throws IOException {
        ProductOrderEvent order = mapper.readValue(consumerRecord.value().toString(), ProductOrderEvent.class);
        processor.processEvent(order);
    }

}
