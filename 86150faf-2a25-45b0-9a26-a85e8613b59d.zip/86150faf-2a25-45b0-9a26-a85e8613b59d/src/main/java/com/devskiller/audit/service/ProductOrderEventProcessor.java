package com.devskiller.audit.service;

import com.devskiller.audit.consumer.ProductOrderEvent;
import com.devskiller.audit.model.ProductOrder;
import com.devskiller.audit.repository.ProductOrderRepository;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;

@Component
public class ProductOrderEventProcessor {
    final private ProductOrderRepository productOrderRepository;

    public ProductOrderEventProcessor(ProductOrderRepository productOrderRepository) {
        this.productOrderRepository = productOrderRepository;
    }

    public void processEvent(ProductOrderEvent event) {
        ProductOrder productOrder = new ProductOrder(event.userLogin(), event.productId(), LocalDateTime.now());
        productOrderRepository.save(productOrder);
    }

}
